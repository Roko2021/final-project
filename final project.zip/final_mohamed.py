import csv
import sys

def main():
    check_right_argv()
    data = []
    with open(sys.argv[1],'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)
    
    out = []
    for row in data:
        statu = select_status(row['hand'])
        age = select_age(row['birthyear'])
        out.append({'name':row['name'],'statu': statu, 'age':age})
    with open (sys.argv[2],'w') as file:
        write = csv.DictWriter(file,fieldnames=['name','statu','age'])
        write.writerow({'name':'name','statu':'statu','age':'age'})
        for row in out:
            write.writerow({'name': row['name'],'statu': row['statu'],'age':row['age']})
        
        
    
    
    
def check_right_argv():
    if len(sys.argv) < 3:
        sys.exit('Too few command-line arguments')
    if len(sys.argv) > 3:
        sys.exit('Too many command-line arguments')
    if '.csv' not in sys.argv[1] or '.csv' not in sys.argv[2]:
        sys.exit('Not txt files')
        
def select_status(hands):
    if hands in ['flower','empty']:
        return 'single'
    if hands in ['ring']:
        return 'related'
    
def select_age(year):
    age = 2024 - int(year)
    return 'His age is: ' + str(age)
    
    
    
if __name__ == '__main__':
    main()