from final_mohamed import check_right_argv,select_age,select_status
import pytest

def test_check_correct_args():
    with pytest.raises(SystemExit):
        check_right_argv()
        
def test_select_status():
    assert select_status('flower') == 'single'
    assert select_status('ring') == 'related'
    
def test_select_age():
    assert select_age(1992) == 'His age is: 32'
    assert select_age(1998) == 'His age is: 26'